import socket
import os
import threading
import time
from datetime import datetime, timedelta
import uuid

# Directory to store files
FILE_DIR = "shared_files"
os.makedirs(FILE_DIR, exist_ok=True)

# File expiration log
file_expirations = {}
expirations_lock = threading.Lock()

# Cleanup expired files
def cleanup_files():
    while True:
        now = datetime.now()
        with expirations_lock:
            for file, expiry in list(file_expirations.items()):
                if now >= expiry:
                    file_path = os.path.join(FILE_DIR, file)
                    if os.path.exists(file_path):
                        print(f"Deleting expired file {file_path}")  # print message
                        os.remove(file_path)
                    del file_expirations[file]
        time.sleep(10)  # Check every 10 seconds

# Handle client connections
def handle_client(client_socket):
    try:
        # Receive file metadata
        metadata = client_socket.recv(1024).decode().strip()
        if ":" not in metadata:
            print(f"Invalid metadata received: {metadata}")
            return

        file_name, expiry_minutes = metadata.split(":", 1)
        expiry_minutes = int(expiry_minutes)

        # Ensure unique file name
        unique_name = f"{uuid.uuid4().hex}_{file_name}"

        # Receive the file data
        file_path = os.path.join(FILE_DIR, unique_name)
        with open(file_path, "wb") as f:
            while True:
                data = client_socket.recv(1024)
                if not data:
                    break
                f.write(data)

        print(f"File {unique_name} saved successfully at {file_path}")  # print message

        # Set file expiration time
        with expirations_lock:
            file_expirations[unique_name] = datetime.now() + timedelta(minutes=expiry_minutes)

        print(f"File expiration for {unique_name} set at {file_expirations[unique_name]}")  # print message
    except ValueError:
        print("Error: Invalid metadata format.")
    except Exception as e:
        print(f"An error occurred while handling the client: {e}")
    finally:
        client_socket.close()

# Start the server
def start_server(host="0.0.0.0", port=5000):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((host, port))
    server_socket.listen(5)
    print(f"Server listening on {host}:{port}")

    # Start cleanup thread
    threading.Thread(target=cleanup_files, daemon=True).start()

    while True:
        client_socket, addr = server_socket.accept()
        print(f"Connection established with {addr}")
        threading.Thread(target=handle_client, args=(client_socket,)).start()

if __name__ == "__main__":
    start_server()