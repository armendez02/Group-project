import os
import socket

def send_file(file_path, expiry_minutes, server_ip, server_port):
    client_socket = None
    try:
        # Check if file exists
        if not os.path.isfile(file_path):
            print(f"Error: File '{file_path}' does not exist.")
            return

        # Extract file name
        file_name = os.path.basename(file_path)

        # Create connection
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect((server_ip, server_port))

        # Send file metadata
        metadata = f"{file_name}:{expiry_minutes}"
        client_socket.send(metadata.encode())
        print(f"Sent metadata: {metadata}")  # Debug message

        # Send file data
        with open(file_path, "rb") as f:
            while chunk := f.read(1024):
                client_socket.send(chunk)
                print(f"Sent {len(chunk)} bytes")  # Debug message

        print(f"File '{file_name}' sent successfully!")
    except FileNotFoundError:
        print("File not found. Please provide a valid file path.")
    except ConnectionRefusedError:
        print("Could not connect to the server. Ensure the server is running and the IP/port is correct.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
    finally:
        if client_socket:
            client_socket.close()

if __name__ == "__main__":
    # Example usage
    try:
        file_path = input("Enter the file path to send: ").strip()
        expiry_minutes = int(input("Enter file expiration time in minutes: ").strip())
        server_ip = input("Enter server IP: ").strip()
        server_port = int(input("Enter server port: ").strip())

        # Validate inputs
        if expiry_minutes <= 0:
            print("Error: Expiry time must be a positive integer.")
            exit()

        if not (1 <= server_port <= 65535):
            print("Error: Server port must be between 1 and 65535.")
            exit()

        send_file(file_path, expiry_minutes, server_ip, server_port)
    except ValueError:
        print("Error: Please enter valid numeric inputs for expiration time and server port.")